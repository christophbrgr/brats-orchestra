# brats-orchestra
BraTS ensemble code based on the Docker images used in the BraTS Challenge 2018

##### Author: Christoph Berger
##### Version: 0.1

:warning: This code is not yet finished and some function stubs may still be present in the code, so you have to check if everything you need is actually implemented

:warning: This code will need nvidia-docker if you are using Docker containers that use the GPU to speed up inference. To install nvidia-docker, follow the guide here: https://github.com/NVIDIA/nvidia-docker

Current functionality:
- `weborchestra.py`provides the interface which can be used by other scripts to perform a given segmentation and fusion on the passed images (4 sequences) - this is to allow efficient queuing of tasks with redis or similar
- `orchestra.py` backend module which returns an Orchestra-Object set up to perform segmentations. Initialize the object with a config.json file containing a list of the containers to use for this segmentation round and with a containers.json file where all the metadata for those containers is stored. *Still work in progress*
- `segment.py` is the front-end script to manage Docker containers for segmentation tasks and organises files to work with the containers *redundant and will be removed*
- `fusion/fusion.py` uses the resulting individual fusions to create a final result (using various methods) *used by weborchestra to perform the fusion*
- `util/` contains various scripts to manage files on the filesystem, calculate metrics for segmentation performance, load and store medical images and more

### Usage of segment.py
```
python3 segment.py /brats/dir/path/
```
`/brats/dir/path/` is the path where all subject folders are located, which must look like this:
- `/brats/dir/path/`
  - `pat123/`
    - `flair.nii.gz`
    - `t1.nii.gz`
    - `t2.nii.gz`
    - `t1c.nii.gz`
  - `pat456/`
    - `...`

And so on.. Resulting segmentations will be placed into `pat123/pat123_<algorithm>_results/tumor_<algorithm>_class.nii.gz`

### Requirements
You need to have a working installation of Docker running on your system. Also, install all other required packages for this code to run using:

```
pip install -r requirements.txt
```

### Current Tasks
- compatibility for automated GPU segmentation using Nvidia-Docker: DONE (via runtime=nvidia)
- log progress in containers
- error handling for failed segmentations
