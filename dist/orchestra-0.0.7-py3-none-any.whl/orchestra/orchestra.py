# -*- coding: utf-8 -*-
# Author: Christoph Berger
# Script for evaluation and bulk segmentation of Brain Tumor Scans
# using the MICCAI BRATS algorithmic repository
#
# Please refer to README.md and LICENSE.md for further documentation
# This software is not certified for clinical use.

__version__ = '0.1'
__author__ = 'Christoph Berger'

import json
import subprocess
import os
import errno
import sys
from pprint import pprint

#set id of gpu to use for computations
gpu = "0"

from .util import filemanager as filemanager

class Orchestra(object):
    def __init__(self, config, verbose=True, tty=False, newdocker=True):
        """ Init the orchestra class with placeholders
        """
        self.noOfContainers = 0
        self.config = []
        self.directory = None
        self.verbose = verbose
        self.tty = tty
        self.dockerGPU = newdocker
        # set environment variables to limit GPU usage
        os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"   # see issue #152
        os.environ["CUDA_VISIBLE_DEVICES"]=gpu
        try:
            configfile = open(config, 'r')
            self.config = json.load(configfile)
            self.noOfContainers = len(self.config.keys())
            configfile.close()
        except IOError as e:
            print('I/O error({0}): {1}'.format(e.errno, e.strerror))
            raise
        except ValueError:
            print('Invalid configuration file')
            raise
        except:
            print('Unexpected Error!')
            raise

    def getFileFormat(self, index):
        return self.config[index]['fileformat']

    def getContainerName(self, index):
        return self.config[index]['name']

    def getNumberOfContainers(self):
        return len(self.config)

    def runDummyContainer(self, stop=False):
        command = "docker run --rm -it hello-world"
        subprocess.check_call(command, shell = True)

    def runContainer(self, id, directory):
        """
        Runs one container on one patient folder
        """
        if self.tty:
            command = "docker run --rm -it "
        else:
            command = "docker run --rm "
        if self.config[id]['runtime'] == 'nvidia':
            if self.dockerGPU:
                command = command + "--gpus all -v " + str(directory) + ":" + str(self.config[id]['mountpoint']) + " " + str(self.config[id]['id']) + " " + str(self.config[id]['command'])
            else:
                command = command + "--runtime=nvidia -v " + str(directory) + ":" + str(self.config[id]['mountpoint']) + " " + str(self.config[id]['id']) + " " + str(self.config[id]['command'])
        else:
            command = command + "-v " + str(directory) + ":" + str(self.config[id]['mountpoint']) + " " + str(self.config[id]['id']) + " " + str(self.config[id]['command'])
        subprocess.check_call(command, shell = True)
        if self.verbose:
            print('Container exited without error')
        return True

    def runIterate(self, dir, cid):
        """ Iterates over a directory and runs the segmentation on each patient found
        """
        print('Looking for BRATS data directories..')
        for fn in os.listdir(dir):
            if not os.path.isdir(os.path.join(dir, fn)):
                continue # Not a directory
            if 'DE_RI' in fn:
                print('Found pat data: ', fn)
                try:
                    os.makedirs(os.path.join(os.path.join(dir, fn),
                    'results'))
                except OSError as err:
                    if err.errno != errno.EEXIST:
                        raise
                print('Calling Container: ', cid)
                if not self.runContainer(cid, os.path.join(dir, fn)):
                    print('ERROR: Run failed for patient ', fn, ' with container', cid)
                    return False
                #TODO: rename folder and prepend pat_id
                #rename_folder(img_id, os.path.join(directory, fn), fn)
        return True
