# -*- coding: utf-8 -*-
# Author: Christoph Berger
# Script for evaluation and bulk segmentation of Brain Tumor Scans
# using the MICCAI BRATS algorithmic repository
#
# Please refer to README.md and LICENSE.md for further documentation
# This software is not certified for clinical use.
#
# This file is part of the weborchestra module to provide a segmentation interface for
# use in our webservice

import sys
import json
import glob
import shutil
import uuid
import os

import os.path as op
import numpy as np

from . import orchestra as orc
from .util import own_itk as oitk
from .util import filemanager as fm

def segment(t1=None, t2=None, t1c=None, flair=None, cid='mocker', outputPath=None, outputName=None, dockers=None, fileformats=None, normalize=False, mask=None, verbose=True, newdocker=True):
    '''
    Segmentation master function
    Returns None if the segmentation has failed for whatever reason!

    Expects 4 modalities as itk images or paths
    outputPath: If none, segmentation is saved in /tmp/results and the full path is returned
    If an outputPath is given, the function saves the resulting image to this location as tumor_segm.nii.gz
    Saves all reveived images to /tmp in the correct format before processing
    fusion_type:
    - None -> only the top performing algorithm is run
    - Top 3 -> top 3 performing algorithms will be run
    - Top 5
    - All -> all available segmentations will be run
    Increased runtime, obviously
    normalize: In case you aren't sure if your image is normalized to the range 0..1, please pass the normalize argument
    returns a (fused) segmentation according to the params set
    '''
    inputs = {'t1':t1, 't2':t2, 't1c':t1c, 'flair':flair}

    # set reference directory for script so it can find all the config files
    spath = op.dirname(op.realpath(__file__))

    # set up orchestra
    if dockers is None:
        config = op.abspath(op.join(spath, 'config/dockers.json'))
    else:
        config = op.abspath(dockers)
    orchestra = orc.Orchestra(config, newdocker=newdocker)

    #load fileformat dict for a given container
    if fileformats is None:
        print('[Weborchestra][Error] No fileformat file specified!')
        ff = _format(orchestra.getFileFormat(cid), op.join(spath, 'config/fileformats.json'))
    else:
        ff = _format(orchestra.getFileFormat(cid), fileformats)

    # create session id
    session = uuid.uuid4().hex[:8]
    # create temporary directory to match ff specs
    directory = op.abspath('./tmp-'+str(session))
    # remove old files
    if op.exists(directory):
        shutil.rmtree(directory, ignore_errors=True)
    # create dirs again
    os.mkdir(directory)
    os.mkdir(op.join(directory, 'results/'))

    # loop through passed images and save them in the correct format
    for key, img in inputs.items():
        savepath = op.join(directory, ff[key])
        img = oitk.get_itk_image(img)
        if normalize:
            # get numpy array and normalize, then transform back to itk image type
            tmp = oitk.get_itk_array(img)
            if mask is None:
                print('[Weborchestra][Warning] No mask provided, will normalize without mask!')
                mask = np.ones(tmp.shape)
            tmp = fm.bratsNormalize(tmp, mask)
            if tmp is None:
                print('[Weborchestra][Error] Normalization failed for sequence {}!'.format(key))
                break
            img = oitk.make_itk_image(tmp, proto_image=img, verbose=verbose)

        if verbose:
            print('[Weborchestra][Info] Writing to path {}'.format(savepath))
        oitk.write_itk_image(img, savepath)
    if verbose:
        print('[Weborchestra][Info] Images saved correctly')
        print('[Weborchestra][Info] Starting the Segmentation with one container now')
    status = orchestra.runContainer(cid, directory)

    respath = op.join(directory, 'results/')
    if status:
        if verbose:
            print('[Weborchestra][Success] Segmentation saved')
        respath = _handleResult(cid, respath, outputPath=outputPath)
        # delete tmp directory if result was saved elsewhere
        if outputPath is not None:
            shutil.rmtree(directory, ignore_errors=True)
        return respath
    if verbose:
        print('[Weborchestra][Error] Segmentation failed, see output!')
    return None

### Private utility methods below ###

def _handleResult(cid, directory, outputPath):
    '''
    This function handles the copying and renaming of the
    Segmentation result before returning
    '''
    # Todo: Find segmentation result
    contents = glob.glob(op.join(directory,'*tumor*.nii*'))
    if len(contents) < 1:
        print("[Weborchestra - Filehandling][Error] No segmentation saved, the container run has most likely failed.")
    elif len(contents) > 1:
        print('[Weborchestra - Filehandling][Warning] Multiple Segmentations Found')
        img = oitk.get_itk_image(contents[0])
    img = oitk.get_itk_image(contents[0])
    if outputPath != None:
        os.makedirs(outputPath, exist_ok=True)
        savePath = op.join(outputPath, 'tumor_segm.nii.gz')
        print('Saving to the user-specified directory:')
        print(savePath)
    else:
        savePath = op.join(directory, 'tumor_segm.nii.gz')
        print('Saving to the temporary directory:')
        print(savePath)
    oitk.write_itk_image(img, savePath)
    return savePath

def _format(fileformat, configpath, verbose=True):
    # load fileformat for a given container
    try:
        configfile = open(op.abspath(configpath), 'r')
        config = json.load(configfile)
        configfile.close()
    except IOError as e:
        print('I/O error({0}): {1}'.format(e.errno, e.strerror))
        raise
    except ValueError:
        print('Invalid configuration file')
        raise
    except:
        print('Unexpected Error!')
        raise
    print('[Weborchestra][Success]Loaded fileformat: {}'.format(config[fileformat]))
    return config[fileformat]
